@extends('admin.main')
@section('content')
    <div class="dash-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="invoice-panel">
                        <div class="act-title d-flex justify-content-between">
                            <h5>Project Landmarks</h5><br>

                            <a href="{{url('admin/projects/landmarks/add/'.$project_id)}}" class="btn v3">Add New Project Landmark</a>
                        </div>

                        <div class="invoice-body">
                            <div class="table-responsive">
                                <table class="invoice-table table" id="package_table">
                                    <thead>
                                    <tr class="invoice-headings">
                                        <th style="max-width:100px">Action</th>
                                        <th>Landmark name</th>
                                        <th>Location</th>
                                        <th>Duration to this location in minutes </th>
                                    </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
<script>
    (function($){
        "use strict";
        $('#package_table').DataTable({
            processing: true,
            serverSide: true,
            responsive: true,
            ajax:{
                url: "{{    url('admin/projects/landmarks/'.$project_id) }}"
            },
            columns:[
                {
                    data: 'action',
                    name: 'action',
                    orderable: false
                },
                {
                    data: 'name',
                    name: 'name'
                },
                {
                    data: 'map_location',
                    name: 'map_location'
                },
                {
                    data: 'location_minutes',
                    name: 'location_minutes'
                }
            ]
        });
    })(jQuery);
</script>

@endpush
